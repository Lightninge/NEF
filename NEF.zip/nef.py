"""The /nef command group (works on every server the bot is in; each server has its own setup)."""
from __future__ import annotations

import hashlib
import secrets
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from ..guilds import GuildConfig
from ..views import FreeAgentView, free_agent_embed


def is_guild_admin(m: discord.Member) -> bool:
    p = m.guild_permissions
    return m.id == m.guild.owner_id or p.administrator or p.manage_guild


class NefCog(commands.GroupCog, group_name="nef", group_description="NEF team management"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    # ---------------------------------------------------------------- helpers
    async def _active(self, interaction: discord.Interaction) -> Optional[GuildConfig]:
        """Guild config if this server is set up and enabled; otherwise answers the user and returns None."""
        if interaction.guild is None or not isinstance(interaction.user, discord.Member):
            await interaction.response.send_message("❌ Use this command inside a server.", ephemeral=True)
            return None
        gc, err = self.bot.invites.active_config(interaction.guild.id)
        if err:
            await interaction.response.send_message(err, ephemeral=True)
        return gc

    async def _admin_only(self, interaction: discord.Interaction) -> Optional[GuildConfig]:
        if interaction.guild is None or not isinstance(interaction.user, discord.Member):
            await interaction.response.send_message("❌ Use this command inside a server.", ephemeral=True)
            return None
        if not is_guild_admin(interaction.user):
            await interaction.response.send_message("🚫 Only server admins (Manage Server) can use this command.", ephemeral=True)
            return None
        gc = await self.bot.gstore.ensure(interaction.guild.id)
        if not gc.enabled:
            await interaction.response.send_message("❌ This bot has been disabled for this server by the bot owner.", ephemeral=True)
            return None
        return gc

    @staticmethod
    def _plain_role_ok(role: discord.Role) -> Optional[str]:
        if role.is_default():
            return "❌ You can't use @everyone."
        if role.managed:
            return "❌ That role is managed by an integration or bot and can't be assigned."
        return None

    # ----------------------------------------------------------- player commands
    @app_commands.command(name="inviteplayer", description="Invite a free agent to your team")
    @app_commands.describe(user="The free agent to invite", team="Your team role")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    async def inviteplayer(self, interaction: discord.Interaction, user: discord.Member, team: discord.Role):
        if await self._active(interaction) is None:
            return
        await interaction.response.defer(ephemeral=True)
        _, text = await self.bot.invites.create_invite(interaction.user, user, team)
        await interaction.followup.send(text, ephemeral=True)

    @app_commands.command(name="removeplayer", description="Remove a player from your team")
    @app_commands.describe(user="The player to remove", team="Your team role")
    @app_commands.checks.cooldown(1, 3.0, key=lambda i: i.user.id)
    async def removeplayer(self, interaction: discord.Interaction, user: discord.Member, team: discord.Role):
        if await self._active(interaction) is None:
            return
        await interaction.response.defer(ephemeral=True)
        ok, text = await self.bot.invites.remove_player(interaction.user, user, team)
        if not ok:
            return await interaction.followup.send(text, ephemeral=True)
        embed = discord.Embed(
            title="Player Removed Successfully ✅",
            description=f"**Player:** {user.mention}\n**Team:** {team.mention}\n**Removed by:** {interaction.user.mention}",
            colour=discord.Colour.green())
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="freeagent", description="Post the Free Agent panel (server owner only)")
    async def freeagent(self, interaction: discord.Interaction):
        gc = await self._active(interaction)
        if gc is None:
            return
        if interaction.user.id != interaction.guild.owner_id:  # owner only: admin permission is NOT enough
            await self.bot.invites.audit(interaction.guild.id, f"🚫 {interaction.user.mention} tried to use /nef freeagent without being the owner.")
            return await interaction.response.send_message("🚫 Only the server owner can use this command.", ephemeral=True)
        if interaction.guild.get_role(gc.free_agent_role_id) is None:
            return await interaction.response.send_message("❌ The configured free-agent role doesn't exist. Run **/nef setup** again.", ephemeral=True)
        try:
            await interaction.channel.send(embed=free_agent_embed(), view=FreeAgentView())
        except (discord.Forbidden, AttributeError):
            return await interaction.response.send_message("❌ I can't post in this channel (need View, Send Messages, Embed Links).", ephemeral=True)
        except discord.HTTPException:
            return await interaction.response.send_message("❌ Discord returned an error while posting the panel.", ephemeral=True)
        await interaction.response.send_message("✅ Free Agent panel posted.", ephemeral=True)

    # ------------------------------------------------------------ admin commands
    @app_commands.command(name="setup", description="Set up the bot for this server (admins). Missing roles/category are created.")
    @app_commands.describe(leader_role="Role that marks team leaders (created as 'team-leader' if omitted)",
                           free_agent_role="Role for players looking for a team (created as 'free-agent' if omitted)",
                           invites_category="Category for temporary invitation channels (created as 'invites' if omitted)",
                           log_channel="Optional channel for the audit log")
    @app_commands.default_permissions(manage_guild=True)
    async def setup(self, interaction: discord.Interaction, leader_role: Optional[discord.Role] = None,
                    free_agent_role: Optional[discord.Role] = None, invites_category: Optional[discord.CategoryChannel] = None,
                    log_channel: Optional[discord.TextChannel] = None):
        gc = await self._admin_only(interaction)
        if gc is None:
            return
        await interaction.response.defer(ephemeral=True)
        guild, notes = interaction.guild, []
        leader_role = leader_role or guild.get_role(gc.leader_role_id or 0)
        free_agent_role = free_agent_role or guild.get_role(gc.free_agent_role_id or 0)
        invites_category = invites_category or (guild.get_channel(gc.invites_category_id) if gc.invites_category_id else None)
        try:
            if leader_role is None:
                leader_role = await guild.create_role(name="team-leader", reason="NEF setup"); notes.append("created role **team-leader**")
            if free_agent_role is None:
                free_agent_role = await guild.create_role(name="free-agent", reason="NEF setup"); notes.append("created role **free-agent**")
            if not isinstance(invites_category, discord.CategoryChannel):
                invites_category = await guild.create_category("invites", reason="NEF setup", overwrites={
                    guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    guild.me: discord.PermissionOverwrite(view_channel=True, manage_channels=True, send_messages=True,
                                                          embed_links=True, manage_messages=True, read_message_history=True)})
                notes.append("created category **invites**")
        except discord.Forbidden:
            return await interaction.followup.send("❌ I need **Manage Roles** and **Manage Channels** to create the missing items. "
                                                   "Grant them, or pass existing roles/category to this command.", ephemeral=True)
        for r in (leader_role, free_agent_role):
            problem = self._plain_role_ok(r)
            if problem:
                return await interaction.followup.send(problem, ephemeral=True)
        if leader_role.id == free_agent_role.id:
            return await interaction.followup.send("❌ The leader role and free-agent role must be different.", ephemeral=True)
        clash = {leader_role.id, free_agent_role.id} & gc.team_role_ids
        if clash:
            return await interaction.followup.send("❌ A team role can't also be the leader or free-agent role. Remove it with **/nef removeteam** first.", ephemeral=True)
        gc.leader_role_id, gc.free_agent_role_id, gc.invites_category_id = leader_role.id, free_agent_role.id, invites_category.id
        if log_channel:
            gc.staff_log_channel_id = log_channel.id
        await self.bot.gstore.save(gc)
        warn = "" if (leader_role.is_assignable() and free_agent_role.is_assignable()) else (
            "\n⚠️ My role is **below** the free-agent role (or I lack Manage Roles). Move my role above all NEF roles in Server Settings → Roles.")
        await self.bot.invites.audit(guild.id, f"⚙️ {interaction.user.mention} ran /nef setup.")
        await interaction.followup.send(
            f"✅ **Setup saved.** Leader: {leader_role.mention} · Free agent: {free_agent_role.mention} · Invites: {invites_category.mention}"
            + (f"\nAlso: {', '.join(notes)}." if notes else "") + warn
            + "\n\nNext: register your teams with **/nef addteam** (one per team role).", ephemeral=True)

    @app_commands.command(name="addteam", description="Register a role as a team (admins)")
    @app_commands.describe(role="The team's role (its name is the team name)")
    @app_commands.default_permissions(manage_guild=True)
    async def addteam(self, interaction: discord.Interaction, role: discord.Role):
        gc = await self._admin_only(interaction)
        if gc is None:
            return
        problem = self._plain_role_ok(role)
        if problem:
            return await interaction.response.send_message(problem, ephemeral=True)
        if role.id in (gc.leader_role_id, gc.free_agent_role_id) or role.id in gc.staff_role_ids:
            return await interaction.response.send_message("❌ That role is already used as leader / free-agent / staff role.", ephemeral=True)
        if role.id in gc.team_role_ids:
            return await interaction.response.send_message("ℹ️ That team is already registered.", ephemeral=True)
        await self.bot.gstore.add_role(gc, role.id, "team")
        await self.bot.invites.audit(interaction.guild.id, f"➕ {interaction.user.mention} registered team {role.name}.", team_id=role.id)
        warn = "" if role.is_assignable() else "\n⚠️ I can't manage this role yet: move my role above it."
        await interaction.response.send_message(f"✅ Team {role.mention} registered.{warn}", ephemeral=True)

    @app_commands.command(name="removeteam", description="Unregister a team role (admins). The Discord role is not deleted.")
    @app_commands.describe(role="The team role to unregister")
    @app_commands.default_permissions(manage_guild=True)
    async def removeteam(self, interaction: discord.Interaction, role: discord.Role):
        gc = await self._admin_only(interaction)
        if gc is None:
            return
        if role.id not in gc.team_role_ids:
            return await interaction.response.send_message("ℹ️ That role isn't a registered team.", ephemeral=True)
        await self.bot.gstore.remove_role(gc, role.id, "team")
        await self.bot.invites.audit(interaction.guild.id, f"➖ {interaction.user.mention} unregistered team {role.name}.", team_id=role.id)
        await interaction.response.send_message(f"✅ {role.mention} is no longer a team.", ephemeral=True)

    @app_commands.command(name="teams", description="Show this server's registered teams and leaders")
    async def teams(self, interaction: discord.Interaction):
        gc = await self._active(interaction)
        if gc is None:
            return
        lines = []
        for rid in sorted(gc.team_role_ids):
            role = interaction.guild.get_role(rid)
            if role is None:
                continue
            leaders = [m for m in role.members if self.bot.invites.is_leader(gc, m) and len(self.bot.invites.team_roles_of(gc, m)) == 1]
            lines.append(f"{role.mention} · {len(role.members)} members · leader: {', '.join(m.mention for m in leaders) or '—'}")
        await interaction.response.send_message(embed=discord.Embed(title="Teams", description="\n".join(lines) or "No teams registered yet. Use **/nef addteam**.",
                                                                    colour=discord.Colour.blurple()), ephemeral=True)

    @app_commands.command(name="staffrole", description="Let a role see invitation channels (admins)")
    @app_commands.describe(role="Staff role", enabled="True to add, false to remove")
    @app_commands.default_permissions(manage_guild=True)
    async def staffrole(self, interaction: discord.Interaction, role: discord.Role, enabled: bool = True):
        gc = await self._admin_only(interaction)
        if gc is None:
            return
        if enabled:
            problem = self._plain_role_ok(role) or ("❌ A team role can't be a staff role." if role.id in gc.team_role_ids else None)
            if problem:
                return await interaction.response.send_message(problem, ephemeral=True)
            await self.bot.gstore.add_role(gc, role.id, "staff")
        else:
            await self.bot.gstore.remove_role(gc, role.id, "staff")
        await interaction.response.send_message(f"✅ {role.mention} {'can now' if enabled else 'can no longer'} see invitation channels.", ephemeral=True)

    @app_commands.command(name="multiteam", description="Allow players to be on several teams at once (admins)")
    @app_commands.default_permissions(manage_guild=True)
    async def multiteam(self, interaction: discord.Interaction, enabled: bool):
        gc = await self._admin_only(interaction)
        if gc is None:
            return
        gc.allow_multiple_teams = enabled
        await self.bot.gstore.save(gc)
        await interaction.response.send_message(f"✅ Multiple teams per player: **{'on' if enabled else 'off'}**.", ephemeral=True)

    @app_commands.command(name="statskey", description="Create an API key for sending player stats to the website (admins)")
    @app_commands.default_permissions(manage_guild=True)
    async def statskey(self, interaction: discord.Interaction):
        gc = await self._admin_only(interaction)
        if gc is None:
            return
        key = secrets.token_urlsafe(32)
        gc.stats_key_hash = hashlib.sha256(key.encode()).hexdigest()  # only the hash is stored
        await self.bot.gstore.save(gc)
        await interaction.response.send_message(
            f"🔑 Your stats API key (shown **once**, any older key is now invalid):\n||`{key}`||\n"
            f"Your server ID for the API is `{interaction.guild.id}`.", ephemeral=True)
