"""Website backend (multi-server): Discord OAuth2 login, bearer-token API, live updates (SSE), super-admin tools.

Runs inside the bot process so it reads *live* Discord state (roles are the source of truth) and shares the
invitation service, database and gateway events with the bot. The site itself is static (index.html) and can be
hosted anywhere, e.g. GitHub Pages: authentication uses an Authorization header, so no third-party cookies are needed.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import html
import logging
import math
import re
import secrets
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import Optional
from urllib.parse import urlencode

import aiohttp
import discord
from aiohttp import web

log = logging.getLogger("nef.web")

DISCORD_API = "https://discord.com/api/v10"
INDEX_FILE = Path(__file__).parent / "web" / "index.html"
STATE_COOKIE = "nef_oauth_state"          # only used during the login redirect (top-level navigation)
TOKEN_TTL_MS = 7 * 24 * 3600 * 1000
COLORS = ["#5865f2", "#2f9e6f", "#d9822b", "#c2478b", "#3b82c4", "#8a5cd0"]
METRIC_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        self.status, self.message = status, message


class _Client:
    __slots__ = ("event", "gids")

    def __init__(self):
        self.event, self.gids = asyncio.Event(), set()


class Hub:
    """Fan-out of 'this server changed' pings to connected dashboards (debounced)."""

    def __init__(self):
        self.clients: set[_Client] = set()
        self._pending: set[str] = set()
        self._handle: Optional[asyncio.TimerHandle] = None

    def notify(self, guild_id: Optional[int] = None) -> None:
        self._pending.add(str(guild_id) if guild_id else "*")
        if self._handle is None:
            self._handle = asyncio.get_running_loop().call_later(0.5, self._flush)

    def _flush(self) -> None:
        pending, self._pending, self._handle = self._pending, set(), None
        for c in list(self.clients):
            c.gids |= pending
            c.event.set()


class RateLimiter:
    def __init__(self):
        self._hits: dict[str, deque] = defaultdict(deque)

    def hit(self, key: str, limit: int, window: int) -> bool:
        now = time.monotonic()
        q = self._hits[key]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        if len(self._hits) > 5000:
            for k in [k for k, v in self._hits.items() if not v or now - v[-1] > window]:
                self._hits.pop(k, None)
        return True


def _fmt_num(v: float):
    return int(v) if float(v).is_integer() else round(v, 2)


def _rel(ts: Optional[int]) -> str:
    if not ts:
        return "never"
    d = max(0, int(time.time()) - ts)
    return "just now" if d < 60 else f"{d // 60} min ago" if d < 3600 else f"{d // 3600} h ago"


class WebServer:
    def __init__(self, bot):
        self.bot, self.cfg, self.hub = bot, bot.cfg, bot.hub
        self.limiter = RateLimiter()
        self._secret = self.cfg.session_secret.encode()
        self._api_secure = self.cfg.public_url.startswith("https://")
        self._frontend_origin = self.cfg.frontend_origin
        self._index = INDEX_FILE.read_bytes()
        self._http: Optional[aiohttp.ClientSession] = None
        self._runner: Optional[web.AppRunner] = None
        self._sse_open = 0

    @property
    def svc(self):
        return self.bot.invites

    @property
    def store(self):
        return self.bot.gstore

    def is_super(self, uid: int) -> bool:
        return uid in self.cfg.super_admin_ids

    # ------------------------------------------------------------- lifecycle
    def make_app(self) -> web.Application:
        app = web.Application(middlewares=[self._middleware], client_max_size=16 * 1024)
        app.on_response_prepare.append(self._headers)
        app.add_routes([
            web.get("/", self.index),
            web.get("/config.js", self.config_js),
            web.route("OPTIONS", "/{tail:.*}", self.preflight),
            web.get("/auth/discord", self.auth_discord),
            web.get("/auth/callback", self.auth_callback),
            web.post("/auth/logout", self.auth_logout),
            web.get("/api/state", self.api_state),
            web.get("/api/events", self.api_events),
            web.post("/api/leader/invite", self.api_leader_invite),
            web.post("/api/leader/remove", self.api_leader_remove),
            web.post("/api/stats", self.api_stats),
            web.get("/api/super/overview", self.api_super_overview),
            web.post("/api/super/guild", self.api_super_guild),
        ])
        return app

    async def start(self) -> None:
        self._http = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))
        self._runner = web.AppRunner(self.make_app(), access_log=None)
        await self._runner.setup()
        await web.TCPSite(self._runner, self.cfg.web_host, self.cfg.web_port).start()
        log.info("API listening on %s:%s (public %s, site %s)", self.cfg.web_host, self.cfg.web_port,
                 self.cfg.public_url, self.cfg.frontend_url or "served by the bot")

    async def stop(self) -> None:
        if self._runner:
            await self._runner.cleanup()
        if self._http:
            await self._http.close()

    # ------------------------------------------------------------ middleware
    def _ip(self, request: web.Request) -> str:
        if self.cfg.trust_proxy:
            fwd = request.headers.get("X-Forwarded-For", "")
            if fwd:
                return fwd.split(",")[-1].strip()
        return request.remote or "?"

    @web.middleware
    async def _middleware(self, request: web.Request, handler):
        kind = "auth" if request.path.startswith("/auth") else "w" if request.method == "POST" else "r"
        if request.method != "OPTIONS" and not self.limiter.hit(f"{self._ip(request)}:{kind}", {"auth": 30, "w": 40, "r": 300}[kind], 60):
            return web.json_response({"error": "Too many requests"}, status=429)
        try:
            return await handler(request)
        except ApiError as e:
            return web.json_response({"error": e.message}, status=e.status)
        except web.HTTPException as e:
            return e
        except Exception:
            log.exception("Unhandled web error on %s", request.path)
            return web.json_response({"error": "Internal error"}, status=500)

    async def _headers(self, request, response) -> None:
        response.headers.update({
            "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
            "Content-Security-Policy": ("default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
                                        "img-src 'self' https://cdn.discordapp.com data:; connect-src 'self'; "
                                        "frame-ancestors 'none'; base-uri 'none'; form-action 'self'"),
        })
        origin = request.headers.get("Origin")
        if self._frontend_origin and origin == self._frontend_origin:  # CORS: exactly one trusted origin, never "*"
            response.headers.update({"Access-Control-Allow-Origin": origin, "Vary": "Origin"})
        if self._api_secure:
            response.headers["Strict-Transport-Security"] = "max-age=31536000"

    # ---------------------------------------------------------------- tokens
    def _sign(self, payload: str) -> str:
        return hmac.new(self._secret, payload.encode(), hashlib.sha256).hexdigest()

    def make_token(self, uid: int) -> str:
        payload = f"{uid}.{int(time.time() * 1000)}"
        return f"{payload}.{self._sign(payload)}"

    async def require_user(self, request: web.Request, mutating: bool = False) -> int:
        """Valid signed bearer token that has not expired or been revoked. Returns the Discord user ID."""
        token = request.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        parts = token.split(".")
        if len(parts) != 3 or not hmac.compare_digest(parts[2], self._sign(f"{parts[0]}.{parts[1]}")):
            raise ApiError(401, "Not logged in")
        try:
            uid, iat = int(parts[0]), int(parts[1])
        except ValueError:
            raise ApiError(401, "Not logged in")
        if iat + TOKEN_TTL_MS < time.time() * 1000:
            raise ApiError(401, "Session expired")
        revoked = await self.bot.db.get_meta(f"revoked:{uid}")
        if revoked and iat <= int(revoked):
            raise ApiError(401, "Session ended")
        if mutating:
            if not request.content_type.startswith("application/json"):
                raise ApiError(415, "JSON required")
            if not self.limiter.hit(f"u{uid}:w", 10, 60):
                raise ApiError(429, "Slow down a little")
        return uid

    # ----------------------------------------------------------------- pages
    async def index(self, request):
        return web.Response(body=self._index, content_type="text/html", charset="utf-8", headers={"Cache-Control": "no-store"})

    async def config_js(self, request):  # same-origin deployment needs no API base
        return web.Response(text="window.NEF_CONFIG = {};\n", content_type="application/javascript", headers={"Cache-Control": "no-store"})

    async def preflight(self, request):
        origin = request.headers.get("Origin")
        if not self._frontend_origin or origin != self._frontend_origin:
            return web.Response(status=403)
        return web.Response(status=204, headers={"Access-Control-Allow-Methods": "GET, POST",
                                                 "Access-Control-Allow-Headers": "Content-Type, Authorization",
                                                 "Access-Control-Max-Age": "600"})

    def _page(self, message: str, status: int):
        body = (f'<!doctype html><meta charset="utf-8"><title>NEF</title><body style="font-family:system-ui;max-width:480px;margin:15vh auto;padding:0 16px">'
                f'<h2>{html.escape(message)}</h2><p><a href="{html.escape(self.cfg.frontend_url or "/")}">Back to the dashboard</a></p>')
        return web.Response(text=body, status=status, content_type="text/html")

    # ----------------------------------------------------------------- OAuth
    async def auth_discord(self, request):
        state = secrets.token_urlsafe(24)
        url = "https://discord.com/oauth2/authorize?" + urlencode({
            "client_id": self.cfg.client_id, "response_type": "code", "scope": "identify",  # only what we need
            "redirect_uri": self.cfg.public_url + "/auth/callback", "state": state, "prompt": "none"})
        resp = web.HTTPFound(url)
        resp.set_cookie(STATE_COOKIE, state, max_age=600, httponly=True, samesite="Lax", secure=self._api_secure, path="/auth")
        return resp

    async def auth_callback(self, request):
        if request.query.get("error"):
            return self._page("Login was cancelled.", 400)
        state, cookie, code = request.query.get("state", ""), request.cookies.get(STATE_COOKIE, ""), request.query.get("code", "")
        if not state or not code or not hmac.compare_digest(state, cookie):
            return self._page("Login failed: invalid state. Please try again.", 400)
        try:
            async with self._http.post(f"{DISCORD_API}/oauth2/token", data={
                "client_id": self.cfg.client_id, "client_secret": self.cfg.client_secret, "grant_type": "authorization_code",
                "code": code, "redirect_uri": self.cfg.public_url + "/auth/callback"}) as r:
                if r.status != 200:
                    return self._page("Discord rejected the login. Please try again.", 502)
                access = (await r.json())["access_token"]
            async with self._http.get(f"{DISCORD_API}/users/@me", headers={"Authorization": f"Bearer {access}"}) as r:
                if r.status != 200:
                    return self._page("Could not read your Discord profile.", 502)
                uid = int((await r.json())["id"])
        except (aiohttp.ClientError, asyncio.TimeoutError, KeyError, ValueError):
            return self._page("Could not reach Discord. Please try again.", 502)
        if not self.is_super(uid) and not self.accessible_guilds(uid):
            return self._page("You are not a member of any server that uses this bot (or it isn't set up yet).", 403)
        # The Discord access token is never stored. The browser only receives our own signed token, in the URL
        # fragment (#token=...), which browsers never send to any server.
        base = (self.cfg.frontend_url or "").rstrip("/") + "/"
        resp = web.HTTPFound(f"{base}#token={self.make_token(uid)}", headers={"Cache-Control": "no-store"})
        resp.del_cookie(STATE_COOKIE, path="/auth")
        return resp

    async def auth_logout(self, request):
        uid = await self.require_user(request)
        await self.bot.db.set_meta(f"revoked:{uid}", str(int(time.time() * 1000)))  # ends every session of this user
        return web.json_response({"ok": True})

    # ------------------------------------------------------------ access model
    def _is_admin(self, m: Optional[discord.Member]) -> bool:
        return bool(m) and (m.id == m.guild.owner_id or m.guild_permissions.administrator or m.guild_permissions.manage_guild)

    def accessible_guilds(self, uid: int) -> list[tuple[discord.Guild, Optional[discord.Member]]]:
        """Servers this person may browse: member of an enabled+configured server (super admin: all servers)."""
        sup, out = self.is_super(uid), []
        for g in self.bot.guilds:
            gc = self.store.get(g.id)
            if gc is None:
                continue
            m = g.get_member(uid)
            if sup or (m is not None and gc.enabled and gc.configured):
                out.append((g, m))
        return sorted(out, key=lambda gm: gm[0].name.lower())

    def _guild_for(self, uid: int, guild_id: str) -> tuple[discord.Guild, Optional[discord.Member]]:
        for g, m in self.accessible_guilds(uid):
            if str(g.id) == str(guild_id):
                return g, m
        raise ApiError(404, "Unknown server")

    def _name(self, guild: discord.Guild, uid: int) -> str:
        m = guild.get_member(uid)
        return m.display_name if m else f"user {uid}"

    def plain(self, guild: Optional[discord.Guild], text: str) -> str:
        if guild is not None:
            text = re.sub(r"<@!?(\d+)>", lambda m: "@" + self._name(guild, int(m[1])), text)
            text = re.sub(r"<@&(\d+)>", lambda m: "@" + (guild.get_role(int(m[1])).name if guild.get_role(int(m[1])) else "role"), text)
        return re.sub(r"\s*<t:\d+:[a-zA-Z]>", "", text)

    def _user(self, m, stats: dict, visible: bool, flags: Optional[dict] = None) -> dict:
        try:
            avatar = str(m.display_avatar.with_size(128).url)
        except Exception:
            avatar = str(m.display_avatar.url)
        s = stats.get(m.id)
        u = {"id": str(m.id), "name": m.display_name, "avatar": avatar, "color": COLORS[m.id % 6],
             "stats": {k: _fmt_num(v) for k, v in s.items()} if (s and visible) else None}
        if flags:
            u.update(flags)
        return u

    async def _me(self, uid: int, member: Optional[discord.Member], stats: dict, admin: bool) -> dict:
        user = member or self.bot.get_user(uid)
        if user is None:
            try:
                user = await self.bot.fetch_user(uid)
            except discord.HTTPException:
                return {"id": str(uid), "name": "You", "avatar": None, "color": COLORS[uid % 6], "stats": None,
                        "admin": admin, "superadmin": self.is_super(uid)}
        return self._user(user, stats, True, {"admin": admin, "superadmin": self.is_super(uid)})

    # -------------------------------------------------------------- snapshot
    async def snapshot(self, guild: discord.Guild, uid: int, viewer: Optional[discord.Member]) -> dict:
        gc, svc = self.store.get(guild.id), self.svc
        sup = self.is_super(uid)
        admin = sup or self._is_admin(viewer)
        my_team_ids = {r.id for r in svc.team_roles_of(gc, viewer)} if viewer else set()
        stats = await self.bot.db.all_stats(guild.id)
        teams, users, problems = [], {}, []
        if not gc.configured:
            problems.append("This server hasn't run /nef setup yet")
        for rid in sorted(gc.team_role_ids):
            role = guild.get_role(rid)
            if role is None:
                problems.append(f"Registered team role {rid} no longer exists on the server")
                continue
            members = sorted(role.members, key=lambda m: m.display_name.lower())
            leaders = []
            for m in members:
                if svc.is_leader(gc, m):
                    if len(svc.team_roles_of(gc, m)) == 1:
                        leaders.append(m)
                    else:
                        problems.append(f"{m.display_name} has the leader role and several team roles: no leadership granted")
            if len(leaders) > 1:
                problems.append(f"{role.name} has {len(leaders)} team leaders")
            for m in members:
                if str(m.id) not in users:
                    shared = bool(my_team_ids & {r.id for r in m.roles})
                    users[str(m.id)] = self._user(m, stats, visible=admin or m.id == uid or shared)
            teams.append({"id": str(role.id), "name": role.name, "leader": str(leaders[0].id) if leaders else None,
                          "leaders": [str(m.id) for m in leaders], "members": [str(m.id) for m in members]})
        teams.sort(key=lambda t: t["name"].lower())
        me = await self._me(uid, viewer, stats, admin)
        users[str(uid)] = me

        held = svc.team_roles_of(gc, viewer) if viewer else []
        leader_team = held[0].id if viewer and svc.is_leader(gc, viewer) and len(held) == 1 else None
        invites, audit = [], []
        if admin or leader_team:
            now = time.time()
            scope = None if admin else leader_team
            for i in await self.bot.db.recent_invites(50, guild.id, scope):
                invites.append({"id": i.id, "team": str(i.team_role_id), "user": self._name(guild, i.player_id), "by": str(i.manager_id),
                                "status": i.status, "exp": f"in {max(1, int((i.expires_at - now) // 60))} min" if i.status == "pending" else "—"})
            for ts, _, text in await self.bot.db.recent_audit(50 if admin else 25, guild.id, scope):
                audit.append({"t": time.strftime("%m-%d %H:%M", time.gmtime(ts)) + " UTC", "msg": self.plain(guild, text)})
        sync = {"gateway": "connected" if self.bot.is_ready() else "reconnecting"}
        if admin:
            last = await self.bot.db.get_meta(f"last_reconcile:{guild.id}")
            sync.update(last=_rel(int(last)) if last else "never", errors=len(problems) + self.bot.reconcile_errors, problems=problems)
        icon = str(guild.icon.with_size(64).url) if guild.icon else None
        return {"guild": {"id": str(guild.id), "name": guild.name, "icon": icon, "enabled": gc.enabled},
                "me": me, "users": users, "teams": teams, "invites": invites, "audit": audit, "sync": sync}

    def _guild_list(self, uid: int) -> list[dict]:
        out = []
        for g, m in self.accessible_guilds(uid):
            gc = self.store.get(g.id)
            role = "superadmin" if self.is_super(uid) and m is None else "admin" if self._is_admin(m) else "member"
            out.append({"id": str(g.id), "name": g.name, "configured": gc.configured, "enabled": gc.enabled, "role": role})
        return out

    # ------------------------------------------------------------------- API
    async def api_state(self, request):
        uid = await self.require_user(request)
        acc = self.accessible_guilds(uid)
        guilds = self._guild_list(uid)
        if not acc:
            me = await self._me(uid, None, {}, False)
            return web.json_response({"guilds": [], "me": me, "users": {}, "teams": [], "invites": [], "audit": [], "sync": {},
                                      "message": "You're not in any server that uses this bot, or the server isn't set up yet."},
                                     headers={"Cache-Control": "no-store"})
        wanted = request.query.get("guild", "")
        guild, member = next((gm for gm in acc if str(gm[0].id) == wanted), acc[0])
        data = await self.snapshot(guild, uid, member)
        data["guilds"] = guilds
        return web.json_response(data, headers={"Cache-Control": "no-store"})

    async def api_events(self, request):
        await self.require_user(request)
        if self._sse_open >= 500:
            raise ApiError(503, "Too many live connections")
        resp = web.StreamResponse(headers={"Content-Type": "text/event-stream", "Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        await resp.prepare(request)
        client = _Client()
        self.hub.clients.add(client)
        self._sse_open += 1
        try:
            await resp.write(b"retry: 3000\n\n")
            while True:
                try:
                    await asyncio.wait_for(client.event.wait(), 20)
                except asyncio.TimeoutError:
                    await resp.write(b": keepalive\n\n")
                    continue
                ids, client.gids = ",".join(sorted(client.gids)), set()
                client.event.clear()
                await resp.write(f"data: {ids}\n\n".encode())
        except (ConnectionResetError, ConnectionError):
            pass
        finally:
            self.hub.clients.discard(client)
            self._sse_open -= 1
        return resp

    async def _json_body(self, request) -> dict:
        try:
            body = await request.json()
        except Exception:
            raise ApiError(400, "Invalid JSON")
        if not isinstance(body, dict):
            raise ApiError(400, "Invalid JSON")
        return body

    def _leader_ctx(self, uid: int, guild_id: str):
        """Guild + member + team a leader may act on. The team comes from the caller's own roles, never from the request."""
        guild, member = self._guild_for(uid, guild_id)
        gc, err = self.svc.active_config(guild.id)
        if err or member is None:
            raise ApiError(403, "This server is not available for team management")
        held = self.svc.team_roles_of(gc, member)
        if not self.svc.is_leader(gc, member) or len(held) != 1:
            raise ApiError(403, "You must be a team leader with exactly one team role on this server")
        return guild, member, held[0]

    def _find_member(self, guild: discord.Guild, query: str) -> discord.Member:
        q = query.strip().lstrip("@").lower()
        if not q:
            raise ApiError(400, "Enter a Discord username")
        if q.isdigit():
            m = guild.get_member(int(q))
            if m:
                return m
        found = [m for m in guild.members if not m.bot and q in {m.name.lower(), (m.global_name or "").lower(), m.display_name.lower()}]
        if not found:
            raise ApiError(404, "No member with that username")
        if len(found) > 1:
            raise ApiError(409, "Several members match; use the numeric Discord user ID instead")
        return found[0]

    async def api_leader_invite(self, request):
        uid = await self.require_user(request, mutating=True)
        body = await self._json_body(request)
        guild, member, team = self._leader_ctx(uid, str(body.get("guild", "")))
        target = self._find_member(guild, str(body.get("username", ""))[:64])
        ok, text = await self.svc.create_invite(member, target, team)  # same validation as /nef inviteplayer
        return web.json_response({"ok": ok, "message": self.plain(guild, text)}, status=200 if ok else 422)

    async def api_leader_remove(self, request):
        uid = await self.require_user(request, mutating=True)
        body = await self._json_body(request)
        guild, member, team = self._leader_ctx(uid, str(body.get("guild", "")))
        raw = str(body.get("user_id", ""))
        target = guild.get_member(int(raw)) if raw.isdigit() else None
        if target is None:
            raise ApiError(404, "Player not found")
        ok, text = await self.svc.remove_player(member, target, team)  # same validation as /nef removeplayer
        if not ok:
            return web.json_response({"ok": False, "message": self.plain(guild, text)}, status=422)
        return web.json_response({"ok": True, "message": f"{target.display_name} was removed from {team.name}"})

    async def api_stats(self, request):
        """POST {guild_id, player_id, metrics:{played:10}} with Authorization: Bearer <server's key from /nef statskey>."""
        body = await self._json_body(request)
        gid, pid, metrics = str(body.get("guild_id", "")), str(body.get("player_id", "")), body.get("metrics")
        gc = self.store.get(int(gid)) if gid.isdigit() else None
        supplied = hashlib.sha256(request.headers.get("Authorization", "").removeprefix("Bearer ").strip().encode()).hexdigest()
        if gc is None or not gc.stats_key_hash or not gc.enabled or not hmac.compare_digest(supplied, gc.stats_key_hash):
            raise ApiError(401, "Invalid server ID or API key")
        guild = self.bot.get_guild(gc.guild_id)
        if guild is None or not pid.isdigit() or guild.get_member(int(pid)) is None:
            raise ApiError(404, "Unknown player")
        if not isinstance(metrics, dict) or not 0 < len(metrics) <= 20:
            raise ApiError(400, "metrics must be an object with 1-20 entries")
        clean = {}
        for k, v in metrics.items():
            if not METRIC_RE.match(str(k)) or isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or abs(v) > 1e12:
                raise ApiError(400, f"Invalid metric {str(k)[:40]!r}: names are lowercase_snake_case, values finite numbers")
            clean[k] = v
        await self.bot.db.upsert_stats(gc.guild_id, int(pid), clean)
        self.hub.notify(gc.guild_id)
        return web.json_response({"ok": True, "updated": sorted(clean)})

    # ---------------------------------------------------------- super admin
    async def _require_super(self, request, mutating=False) -> int:
        uid = await self.require_user(request, mutating)
        if not self.is_super(uid):
            await self.bot.db.add_audit(int(time.time()), 0, None, f"🚫 Non-super user {uid} tried a super-admin endpoint")
            raise ApiError(403, "Super admin only")
        return uid

    async def api_super_overview(self, request):
        await self._require_super(request)
        pend = await self.bot.db.pending_counts()
        guilds = []
        for g in sorted(self.bot.guilds, key=lambda g: g.name.lower()):
            gc = self.store.get(g.id)
            if gc is None:
                continue
            guilds.append({"id": str(g.id), "name": g.name, "members": g.member_count, "owner": str(g.owner_id),
                           "configured": gc.configured, "enabled": gc.enabled, "teams": len(gc.team_role_ids),
                           "pending": pend.get(g.id, 0), "joined": time.strftime("%Y-%m-%d", time.gmtime(gc.joined_at))})
        audit = []
        for ts, gid, text in await self.bot.db.recent_audit(100):
            g = self.bot.get_guild(gid)
            audit.append({"t": time.strftime("%m-%d %H:%M", time.gmtime(ts)) + " UTC", "server": g.name if g else str(gid), "msg": self.plain(g, text)})
        return web.json_response({"guilds": guilds, "audit": audit, "errors": self.bot.reconcile_errors}, headers={"Cache-Control": "no-store"})

    async def api_super_guild(self, request):
        uid = await self._require_super(request, mutating=True)
        body = await self._json_body(request)
        gid, action = str(body.get("guild_id", "")), body.get("action")
        guild = self.bot.get_guild(int(gid)) if gid.isdigit() else None
        gc = self.store.get(int(gid)) if gid.isdigit() else None
        if gc is None or action not in ("enable", "disable", "leave"):
            raise ApiError(400, "Unknown server or action")
        if action in ("enable", "disable"):
            gc.enabled = action == "enable"
            await self.store.save(gc)
            await self.svc.audit(gc.guild_id, f"🛠️ Super admin {action}d the bot for this server.")
            msg = f"Bot {action}d for {guild.name if guild else gid}"
        else:
            if guild is None:
                raise ApiError(404, "The bot is not in that server")
            name = guild.name
            await self.svc.audit(gc.guild_id, f"🛠️ Super admin removed the bot from {name}.")
            await guild.leave()
            msg = f"Left {name}"
        self.hub.notify(gc.guild_id)
        return web.json_response({"ok": True, "message": msg})
