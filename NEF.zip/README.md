# NEF Team Management: multi-server bot + website

One bot that any number of Discord servers can use. Every server has its own teams, leaders, free agents, invitations and statistics.
**You are the super admin**: you see and control every server from the website. Discord roles stay the source of truth.

```
nef_bot/
  bot.py          entry point, gateway events, server join/leave
  config.py       global settings (.env): token, super admins, URLs
  guilds.py       per-server settings (cached, stored in SQLite)
  db.py           SQLite schema (servers, invitations, audit, stats)
  invites.py      invitation lifecycle, validation, cleanup, recovery
  views.py        embeds + persistent buttons
  cogs/nef.py     the /nef commands
  web.py          API: Discord login, bearer tokens, live updates, super-admin tools
  web/index.html  the dashboard (static)   web/config.js  its API address
tests/            55 permission + tenant-isolation checks
```

## How it fits together

```
 Browser ──► https://nef.github.io  (static dashboard on GitHub Pages)
    │
    └──────► https://<your-bot-host>  (bot + API, always on)  ◄──► Discord
```
GitHub Pages only serves static files, so **the bot and its API must run on an always-on host** (Fly.io, Railway, Render, a VPS...) with a persistent disk for `nef.db`.
Login uses a signed token in the `Authorization` header, so no cookies are needed and **no custom domain is required**.

## 1. Discord application (once)
1. <https://discord.com/developers/applications> → New Application.
2. **Bot**: copy the token → `DISCORD_TOKEN`. Enable **Server Members Intent**. Turn **Public Bot** ON so other servers can add it.
3. **OAuth2**: copy Client ID / Client Secret → `.env`. Under **Redirects** add `PUBLIC_URL/auth/callback` (the API address, e.g. `https://nef-bot.fly.dev/auth/callback`).
4. **Invite link** (OAuth2 → URL Generator): scopes `bot` + `applications.commands`; permissions *Manage Roles, Manage Channels, View Channels, Send Messages, Embed Links, Read Message History, Manage Messages*. Share this link: anyone with "Manage Server" can add the bot.
5. Your own Discord user ID → `SUPER_ADMIN_IDS` in `.env` (Developer Mode → right-click yourself → Copy User ID).

> Discord requires verification and approval of the Members intent once a bot is in **100+ servers**.

## 2. Run the bot + API
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill it in
python -m nef_bot.bot
```
Production `.env` highlights: `PUBLIC_URL=https://<your-bot-host>`, `FRONTEND_URL=https://nef.github.io`, `TRUST_PROXY=true` (behind HTTPS proxy). Use a persistent volume for `DATABASE_PATH`. Run **one instance only**. Slash commands are global (a new server may take up to ~1 hour to show them).
Start with a fresh `nef.db` if you used an earlier single-server version (the schema changed).

## 3. Publish the site on GitHub Pages (`nef.github.io`)
1. Create the repository named exactly **`NEF.github.io`** (user/organisation `NEF`).
2. Upload the two files from `nef_bot/web/` to the repository root: `index.html` and `config.js`.
3. Edit `config.js`: `window.NEF_CONFIG = { API_BASE: "https://<your-bot-host>" };`
4. Repository → Settings → Pages → deploy from branch `main`, folder `/ (root)`.
5. Bot `.env`: `FRONTEND_URL=https://nef.github.io`, then restart the bot.

Note: GitHub Pages cannot send security headers, so the page relies on strict output escaping. The API itself sets strict headers and only allows CORS from `FRONTEND_URL`.

## 4. Setting up a server (done by that server's admins)
| Command | Who | What |
|---|---|---|
| `/nef setup` | Manage Server | Sets leader role, free-agent role and invites category (**created automatically if omitted**); optional `log_channel` |
| `/nef addteam <role>` / `removeteam` | Manage Server | Register / unregister a team role (team name = role name) |
| `/nef teams` | anyone | List teams and leaders |
| `/nef staffrole <role>` | Manage Server | Role that may see invitation channels |
| `/nef multiteam <on/off>` | Manage Server | Allow several teams per player (default off) |
| `/nef statskey` | Manage Server | Create the server's stats API key (shown once; only its hash is stored) |
| `/nef freeagent` | **Server owner only** | Post the Free Agent panel (button survives restarts) |
| `/nef inviteplayer <user> <team>` | team leader | Invite a free agent (private channel + DM, Sign/Deny buttons, 10 min expiry) |
| `/nef removeplayer <user> <team>` | team leader | Remove a player from your own team |

Deleting a registered team role in Discord unregisters it automatically.
Rules per server: leader = leader role + exactly one team role; invitations/removals only for your own team.

## 5. You as super admin
- Add your ID to `SUPER_ADMIN_IDS`. In the dashboard a **Super** tab appears.
- It lists **every server** (members, teams, pending invitations, status), a **global activity log**, and buttons to **Disable / Enable** the bot per server or make it **Leave**.
- You can open any server's dashboard (as admin), even if you are not a member.
- You get a DM when the bot is added to a new server.
- Disabled servers: commands and buttons stop working and members lose website access immediately.
- Super admin does **not** bypass the leader rules in Discord (invite/remove still require being that team's leader): a deliberate safety choice.

## 6. Website behaviour
- **Browse per server**: a server picker in the header; the choice is remembered.
- Only servers where you are a member (and that are set up and enabled) are listed. Server admin = owner / Administrator / Manage Server.
- Visibility: everyone sees teams, leaders, members. Stats: the player, teammates and admins. Invitations/audit: leader sees own team only, admins see their server.
- Live updates: gateway events (roles, members) → server-sent events tagged with the server ID → the dashboard refreshes only if that server is open. 5-minute reconcile per server + 60 s browser refresh cover missed events.
- Security: Discord OAuth2 `identify` only (token never stored); signed 7-day tokens in `Authorization` (logout revokes all of a user's sessions); every request re-reads live roles; leader actions derive the team from the caller's own roles; per-IP and per-user rate limits; strict CSP/HSTS on the API.

## 7. Statistics (never invented)
Empty state until real data arrives. Each server admin runs `/nef statskey`, then their match tracker calls:
```bash
curl -X POST "$API/api/stats" -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"guild_id":"<server id>","player_id":"<discord id>","metrics":{"played":24,"wins":15,"losses":9,"points":312}}'
```
A key only works for its own server. New metrics appear automatically; add a label/derived value in `STAT_DEFS` (`index.html`).

## 8. Tests
```bash
PYTHONPATH=. python tests/test_web_permissions.py     # 55 PASS/FAIL checks
```

## 9. Testing checklist (real servers)
☐ Add the bot to two test servers; run `/nef setup` and `/nef addteam` in each ☐ the two servers' teams never mix on the website ☐ log in with Discord; picker lists only your servers ☐ **Super** tab shows both servers; Disable one → its members lose access and commands refuse ☐ leader of server A cannot remove/invite in server B ☐ invite flow (channel + DM, Sign, Deny, expiry, restart recovery) ☐ delete a team role → it disappears from the site ☐ `/nef statskey` + curl shows stats only on that server ☐ stop the bot, change roles, start → site correct after reconcile.
